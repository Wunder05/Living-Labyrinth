"""Живой лабиринт: игровой цикл, интерфейс и программная графика.

Генерация вынесена в generation.py, а синтез звука — в audio.py. Этот файл
отвечает за ввод, правила взаимодействия и превращение сетки в игровой мир.
"""
import asyncio
import math
import random
import sys
from pathlib import Path

import pygame
from audio import AudioSystem
from generation import ALGORITHMS, WIDTH, HEIGHT, generate

# Внутреннее разрешение фиксировано, а итоговый кадр масштабируется под экран.
BASE = Path(__file__).parent
W, H = 1280, 800
BG = (7, 15, 17)
PANEL = (15, 28, 30)
LINE = (42, 65, 62)
TEXT = (239, 242, 226)
MUTED = (177, 198, 187)
GOLD = (222, 179, 99)
CYAN = (91, 224, 211)
TILE = 32
MAPX, MAPY = 44, 170

# Dummy-драйверы в тестах позволяют выполнять весь файл без окна и аудиокарты.
pygame.init()
screen=pygame.display.set_mode((W,H),0 if sys.platform=='emscripten' else pygame.RESIZABLE)
pygame.display.set_caption('Живой лабиринт')
canvas=pygame.Surface((W,H))
fonts={}
text_cache={}
glow_cache={}
spider_cache={}

def font(size):
    if size not in fonts:fonts[size]=pygame.font.Font(str(BASE/'assets'/('font-bold.ttf' if size>=21 else 'font.ttf')),size)
    return fonts[size]

def text(message,x,y,size=18,color=TEXT,center=False,surface=None):
    """Выводит текст через кэш: повторная растеризация в WASM очень дорогая."""
    surface=surface or canvas
    key=(str(message).replace('→','>'),size,color)
    if key not in text_cache:
        if len(text_cache)>512:text_cache.clear()
        text_cache[key]=font(size).render(key[0],True,color)
    im=text_cache[key]
    surface.blit(im,im.get_rect(center=(x,y)) if center else (x,y))
    return im.get_width()

def wrap(message,x,y,width,size=17,color=MUTED,line=26):
    words=message.split();current=''
    for word in words:
        candidate=(current+' '+word).strip()
        if font(size).size(candidate)[0]>width and current:
            text(current,x,y,size,color);y+=line;current=word
        else:current=candidate
    if current:text(current,x,y,size,color);y+=line
    return y

def box(rect,color=PANEL,border=LINE,radius=12):
    """Рисует панель интерфейса в едином визуальном стиле."""
    pygame.draw.rect(canvas,color,rect,border_radius=radius)
    if border:
        pygame.draw.rect(canvas,border,rect,1,border_radius=radius)


def code_block(lines, rect):
    """Показывает короткий учебный фрагмент с простой подсветкой синтаксиса."""
    box(rect, (7, 16, 19), (39, 70, 67), 8)
    x, y, width, _ = rect
    text("PYTHON · УПРОЩЁННЫЙ ФРАГМЕНТ", x + 12, y + 8, 12, GOLD)
    for number, line in enumerate(lines[:5], 1):
        yy = y + 31 + (number - 1) * 23
        text(str(number), x + 10, yy, 13, (80, 110, 103))
        color = (130, 160, 151) if line.lstrip().startswith("#") else (198, 239, 227)
        text(line, x + 29, yy, 15, color)


def glow(surface,xy,radius,color,strength=90):
    """Использует готовый градиент вместо десятков окружностей каждый кадр."""
    r=int(radius);key=(r,color,strength)
    if key not in glow_cache:
        s=pygame.Surface((r*2+2,r*2+2),pygame.SRCALPHA)
        for rr in range(r,1,-3):
            alpha=int(strength*(1-rr/r)**2)
            pygame.draw.circle(s,(*color,alpha),(r,r),rr)
        glow_cache[key]=s
    surface.blit(glow_cache[key],(int(xy[0])-r,int(xy[1])-r))

def diamond(surface,x,y,size=8,color=CYAN):
    pygame.draw.polygon(surface,(18,52,54),[(x,y-size-2),(x+size+2,y),(x,y+size+2),(x-size-2,y)])
    pygame.draw.polygon(surface,color,[(x,y-size),(x+size*.6,y-1),(x,y+size),(x-size*.6,y+1)])
    pygame.draw.polygon(surface,(210,255,247),[(x,y-size),(x+size*.6,y-1),(x-1,y+2)])

def hero(surface,x,y,t,scale=1):
    def pts(seq):return [(x+a*scale,y+b*scale) for a,b in seq]
    pygame.draw.ellipse(surface,(6,12,13),(x-10*scale,y+5*scale,22*scale,8*scale))
    pygame.draw.polygon(surface,(24,22,21),pts([(-7,2),(-9,13),(-3,12),(0,6),(4,13),(10,13),(6,2)]))
    pygame.draw.polygon(surface,(101,76,49),pts([(-8,-5),(-7,7),(0,10),(8,6),(7,-6),(0,-12)]))
    pygame.draw.polygon(surface,(48,40,32),pts([(-9,-4),(-6,-11),(0,-15),(7,-10),(10,-3),(5,3),(-4,3)]))
    pygame.draw.polygon(surface,(16,21,20),pts([(-5,-4),(0,-9),(5,-4),(4,1),(-4,1)]))
    pygame.draw.line(surface,(240,222,175),(x-2*scale,y-2*scale),(x+2*scale,y-2*scale),max(1,int(2*scale)))
    pygame.draw.line(surface,(119,78,41),(x-6*scale,y+2*scale),(x-14*scale,y-15*scale),max(2,int(3*scale)))
    flicker=math.sin(t*11)*2
    pygame.draw.polygon(surface,(255,135,42),pts([(-16,-14),(-18,-21),(-14,-30-flicker),(-10,-20),(-11,-15)]))
    pygame.draw.polygon(surface,(255,229,131),pts([(-15,-15),(-16,-21),(-13,-25-flicker),(-12,-17)]))

def spider_shape(surface,x,y,t,index):
    pygame.draw.ellipse(surface,(6,12,14),(x-12,y+3,25,10))
    for side in (-1,1):
        for leg in range(3):
            wobble=math.sin(t*7+leg+index)*2
            points=[(x+side*4,y-3+leg*3),(x+side*11,y-9+leg*7+wobble),(x+side*15,y-5+leg*7)]
            pygame.draw.lines(surface,(38,27,27),False,points,4)
            pygame.draw.lines(surface,(97,48,39),False,points,1)
    pygame.draw.ellipse(surface,(55,34,32),(x-7,y-7,15,15))
    pygame.draw.circle(surface,(247,80,65),(int(x-3),int(y-3)),2)
    pygame.draw.circle(surface,(247,80,65),(int(x+3),int(y-3)),2)

def spider(surface,x,y,t,index):
    """Кэширует 48 фаз анимации каждого стража, сохраняя движение ног."""
    phase=int(t*12)%48;key=(index,phase)
    if key not in spider_cache:
        sprite=pygame.Surface((40,40),pygame.SRCALPHA)
        spider_shape(sprite,20,20,phase/12,index)
        spider_cache[key]=pygame.transform.scale(sprite,(50,50))
    surface.blit(spider_cache[key],(x-25,y-25))


def terrain(grid, seed, tile=TILE, algorithm="dfs"):
    """Строит текстуру карты один раз после генерации.

    Отдельный Random(seed) повторяет не только стены, но и трещины, мох и камни.
    Алгоритмы слегка различаются оттенком, но остаются в единой тёмной палитре.
    """
    palette = {
        "dfs": ((30, 52, 44), (57, 76, 63)),
        "prim": ((27, 43, 53), (48, 66, 73)),
        "bsp": ((48, 43, 34), (72, 68, 54)),
        "cave": ((39, 35, 51), (59, 56, 69)),
    }
    wall_color, floor_color = palette[algorithm]

    def shade(color, amount):
        return tuple(max(0, min(255, c + amount)) for c in color)

    rng = random.Random(seed)
    surface = pygame.Surface((WIDTH * tile, HEIGHT * tile))
    surface.fill((7, 15, 16))
    for y, row in enumerate(grid):
        for x, wall in enumerate(row):
            px, py = x * tile, y * tile
            variation = rng.randrange(-7, 8)
            if wall:
                # Неровный многоугольник и скошенная кромка имитируют камень.
                pygame.draw.rect(surface, shade(wall_color, variation - 14), (px, py, tile, tile))
                inset = max(1, tile // 16)
                points = [(px + inset, py + 3), (px + tile // 3, py),
                          (px + tile - 2, py + 2), (px + tile - 1, py + tile - 4),
                          (px + tile // 2, py + tile - 1), (px + 2, py + tile - 3)]
                pygame.draw.polygon(surface, shade(wall_color, variation), points)
                if tile > 20:
                    pygame.draw.lines(surface, shade(wall_color, variation + 17), False, points[:3], 1)
                    pygame.draw.line(surface, (12, 25, 25), (px + tile - 3, py + 5),
                                     (px + tile - 3, py + tile - 3), 2)
                    if rng.random() < .34:  # Короткая трещина, не влияющая на коллизии.
                        cx, cy = px + rng.randrange(6, tile - 6), py + rng.randrange(6, tile - 6)
                        pygame.draw.lines(surface, shade(wall_color, -22), False,
                                          [(cx - 4, cy - 3), (cx, cy), (cx - 2, cy + 5)], 1)
                    if rng.random() < .23:  # Мох смягчает геометричность клеток.
                        pygame.draw.ellipse(surface, (39, 67, 48),
                                            (px + 3, py + tile - 7, tile // 2, 4))
            else:
                pygame.draw.rect(surface, shade(floor_color, variation), (px, py, tile, tile))
                if tile > 20:
                    # Каменные плиты, потертости и редкая галькa видны на полу.
                    pygame.draw.line(surface, shade(floor_color, variation - 12),
                                     (px, py + tile - 1), (px + tile, py + tile - 1))
                    pygame.draw.line(surface, shade(floor_color, variation + 6),
                                     (px + 1, py + 2), (px + tile - 2, py + 2))
                    if rng.random() < .48:
                        xx, yy = px + rng.randrange(4, tile - 4), py + rng.randrange(4, tile - 4)
                        pygame.draw.ellipse(surface, shade(floor_color, -23), (xx, yy, 4, 2))
                    if rng.random() < .18:
                        xx, yy = px + rng.randrange(7, tile - 7), py + rng.randrange(7, tile - 7)
                        pygame.draw.lines(surface, shade(floor_color, -20), False,
                                          [(xx - 4, yy), (xx, yy + 2), (xx + 4, yy - 2)], 1)
                # Тень от верхней стены создаёт глубину без внешних спрайтов.
                if y and grid[y - 1][x]:
                    pygame.draw.rect(surface, (21, 34, 32), (px, py, tile, max(1, tile // 5)))
    return surface

class Game:
    """Состояние приложения и все переходы между игрой и обучением."""

    def __init__(self):
        self.mode = "menu"
        self.selected = 0
        self.level = None
        self.t = 0
        self.buttons = []
        self.frame = 0
        self.auto = False             # Автопоказ учебных шагов.
        self.stepclock = 0
        self.lesson_speed = 1         # 0.5, 1, 2 или 4 скорости демонстрации.
        self.paused = False
        self.mouse = (0, 0)
        self.mouse_down = False
        self.fingers = {}             # Позиции активных касаний для мультитач.
        self.toast = ""
        self.toast_time = 0
        self.audio = AudioSystem()
        self.footstep_clock = 0

        # Миниатюры в меню получены настоящими генераторами, а не картинками.
        self.preview = []
        for i, algorithm in enumerate(ALGORITHMS):
            level = generate(algorithm[0], 314 + i)
            self.preview.append(terrain(level.grid, level.seed, 10, level.algorithm))

        # Тёплое свечение факела и заранее построенная градиентная маска тьмы.
        self.light = pygame.Surface((340, 340), pygame.SRCALPHA)
        glow(self.light, (170, 170), 168, (243, 181, 83), 46)
        self.torch_cutout = pygame.Surface((360, 360), pygame.SRCALPHA)
        for radius in range(178, 0, -3):
            alpha = int(215 * (1 - radius / 178) ** 1.5)
            pygame.draw.circle(self.torch_cutout, (0, 0, 0, alpha), (180, 180), radius)
        self.darkness = pygame.Surface((WIDTH * TILE, HEIGHT * TILE), pygame.SRCALPHA)

        # Кнопки остаются доступны мышью и касанием; внешняя панель дублирует их.
        self.dpad = {
            "up": pygame.Rect(1002, 572, 68, 62),
            "left": pygame.Rect(928, 640, 68, 62),
            "down": pygame.Rect(1002, 640, 68, 62),
            "right": pygame.Rect(1076, 640, 68, 62),
        }

    def button(self,label,rect,action,primary=False,active=False,small=False):
        rect=pygame.Rect(rect);hover=rect.collidepoint(self.mouse)
        color=(202,169,100) if primary else ((36,58,56) if hover or active else (22,37,38))
        box(rect,color,GOLD if primary or active else LINE,8)
        text(label,rect.centerx,rect.centery,16 if small else 18,(17,30,29) if primary else TEXT,True)
        self.buttons.append((rect,action))

    def start(self, tutorial=False, fresh=True):
        """Создаёт карту или переносит игрока на уже выбранную учебную карту."""
        if fresh or self.level is None:
            seed = random.SystemRandom().randrange(2 ** 30)
            self.level = generate(ALGORITHMS[self.selected][0], seed)
        self.board = terrain(self.level.grid, self.level.seed, algorithm=self.level.algorithm)
        self.reset_play()
        self.mode = "learn" if tutorial else "play"
        self.frame = 0
        self.auto = False
        self.stepclock = 0
        self.lesson_board = None

    def reset_play(self):
        """Сбрасывает только игровые объекты, сохраняя сгенерированную сетку."""
        self.player = [float(self.level.start[0]), float(self.level.start[1])]
        self.health = 3
        self.invincible = 0
        self.collected = set()
        self.paused = False
        self.footstep_clock = 0
        self.enemies = [{"p": [float(route[0][0]), float(route[0][1])],
                         "i": 1, "dir": 1, "route": route}
                        for route in self.level.patrols]
        self.fingers.clear()
        self.mouse_down = False

    def action(self, action):
        """Единая точка обработки кнопок: так мышь и касания ведут себя одинаково."""
        self.audio.unlock()  # Первый жест одновременно разрешает Web Audio.
        if action != "mute":
            self.audio.play("click", .45)
        if action.startswith("select:"):
            self.selected = int(action.split(":")[1])
        elif action == "play":
            self.start()
        elif action in ("learn", "intro"):
            self.mode = "intro"
            self.auto = False
        elif action.startswith("chapter:"):
            self.selected = int(action.split(":")[1])
            self.start(True)
        elif action == "menu":
            self.mode = "menu"
            self.paused = False
            self.fingers.clear()
        elif action == "credits":
            self.mode = "credits"
        elif action == "retry":
            self.reset_play()
            self.mode = "play"
        elif action == "pause":
            self.paused = not self.paused
            self.fingers.clear()
        elif action == "step":
            self.auto = False
            self.advance()
        elif action == "auto":
            self.auto = not self.auto
            self.stepclock = 0
        elif action == "speed":
            speeds = [.5, 1, 2, 4]
            self.lesson_speed = speeds[(speeds.index(self.lesson_speed) + 1) % len(speeds)]
        elif action == "regenerate":
            self.start(tutorial=True, fresh=True)
        elif action == "back":
            self.frame = max(0, self.frame - 1)
            self.auto = False
            self.lesson_board = None
        elif action == "lessonplay":
            self.reset_play()
            self.mode = "play"
        elif action == "thislearn":
            self.mode = "learn"
            self.frame = 0
            self.auto = False
            self.lesson_board = None
            self.fingers.clear()
        elif action == "mute":
            self.audio.toggle()

    def advance(self):
        """Переходит к следующему снимку и останавливает автопоказ в финале."""
        if self.frame < len(self.level.frames) - 1:
            self.frame += 1
            self.audio.play("tick", .55)
        self.lesson_board = None
        if self.frame == len(self.level.frames) - 1:
            self.auto = False

    def position(self,p):return MAPX+(p[0]+.5)*TILE,MAPY+(p[1]+.5)*TILE

    def can_move(self, x, y):
        """Проверяет четыре угла героя, чтобы он не входил в стены."""
        radius = .24
        for xx in (x - radius, x + radius):
            for yy in (y - radius, y + radius):
                gx, gy = math.floor(xx + .5), math.floor(yy + .5)
                if not (0 <= gx < WIDTH and 0 <= gy < HEIGHT) or self.level.grid[gy][gx]:
                    return False
        return True

    def update(self, dt):
        """Обновляет обучение, движение, столкновения и условия завершения."""
        self.t += dt
        self.toast_time = max(0, self.toast_time - dt)
        if self.mode == "learn" and self.auto:
            self.stepclock += dt
            delay = 6.0 / self.lesson_speed
            if self.stepclock >= delay:
                self.advance()
                self.stepclock = 0
        if self.mode != "play" or self.paused:
            return

        # Объединяем клавиатуру, канвас и внешнюю сенсорную панель браузера.
        self.invincible = max(0, self.invincible - dt)
        keys = pygame.key.get_pressed()
        controls = {key: False for key in self.dpad}
        for position in list(self.fingers.values()) + ([self.mouse] if self.mouse_down else []):
            for key, rect in self.dpad.items():
                if rect.collidepoint(position):
                    controls[key] = True
        if sys.platform == "emscripten":
            import platform
            try:
                for key in controls:
                    controls[key] |= bool(getattr(platform.window, "maze_" + key))
            except (AttributeError, TypeError):
                pass
        dx = int(keys[pygame.K_d] or keys[pygame.K_RIGHT] or controls["right"]) - int(keys[pygame.K_a] or keys[pygame.K_LEFT] or controls["left"])
        dy = int(keys[pygame.K_s] or keys[pygame.K_DOWN] or controls["down"]) - int(keys[pygame.K_w] or keys[pygame.K_UP] or controls["up"])
        movement = 3.5 * dt / (math.sqrt(2) if dx and dy else 1)
        x, y = self.player
        if self.can_move(x + dx * movement, y):
            x += dx * movement
        if self.can_move(x, y + dy * movement):
            y += dy * movement
        self.player = [x, y]
        if dx or dy:
            self.footstep_clock -= dt
            if self.footstep_clock <= 0:
                self.audio.play("step", .34)
                self.footstep_clock = .32

        # Сбор кристаллов открывает выход и запускает соответствующий звук.
        for i, position in enumerate(self.level.crystals):
            if math.dist(self.player, position) < .55 and i not in self.collected:
                self.collected.add(i)
                opened = len(self.collected) == 3
                self.toast = "Портал открыт. Найдите выход!" if opened else "Кристалл найден"
                self.toast_time = 2.5
                self.audio.play("portal" if opened else "crystal", .75)

        # Стражи ходят по готовым маршрутам; контакт даёт 1,8 с неуязвимости.
        for enemy in self.enemies:
            route = enemy["route"]
            target = route[enemy["i"]]
            position = enemy["p"]
            distance = math.dist(position, target)
            step = dt * 1.15
            if distance <= step:
                enemy["p"] = [float(target[0]), float(target[1])]
                if enemy["i"] in (0, len(route) - 1):
                    enemy["dir"] *= -1
                enemy["i"] += enemy["dir"]
            else:
                enemy["p"] = [position[0] + (target[0] - position[0]) / distance * step,
                              position[1] + (target[1] - position[1]) / distance * step]
            if not self.invincible and math.dist(self.player, enemy["p"]) < .60:
                self.health -= 1
                self.invincible = 1.8
                self.audio.play("hit", .8)
                if self.health <= 0:
                    self.mode = "lost"
                    self.audio.play("lose", .7)
                    return
        if len(self.collected) == 3 and math.dist(self.player, self.level.exit) < .6:
            self.mode = "won"
            self.audio.play("win", .8)

    def header(self):
        """Общая шапка: название и доступная на любом экране кнопка звука."""
        diamond(canvas, 43, 44, 11, GOLD)
        text("ЖИВОЙ ЛАБИРИНТ", 67, 31, 22)
        text("ИГРА, КОТОРАЯ СОЗДАЁТ СЕБЯ", 67, 59, 11, MUTED)
        pygame.draw.line(canvas, LINE, (32, 96), (1248, 96))
        self.button("Звук: выкл" if self.audio.muted else "Звук: вкл",
                    (1010, 34, 114, 42), "mute", small=True)

    def menu(self):
        a=ALGORITHMS[self.selected]
        text('01 — ВЫБЕРИТЕ СВОЙ ПУТЬ',40,124,13,GOLD)
        text('Каждый вход —',38,157,48)
        text('новый лабиринт.',38,216,48)
        wrap('Три кристалла откроют портал. Избегайте стражей и узнайте, как алгоритмы создают миры.',40,286,600,19,MUTED,29)
        self.button('Войти в лабиринт',(40,365,240,52),'play',True)
        self.button('Обучение: 4 алгоритма',(294,365,258,52),'learn')
        # Live map specimen, drawn from the selected real generator.
        box((722,121,516,297),(14,26,28),LINE)
        preview=pygame.transform.scale(self.preview[self.selected],(396,276))
        canvas.blit(preview,(782,130))
        glow(canvas,(983,268),110,(79,188,166),33)
        hero(canvas,982,269,self.t,2.4)
        for p in [(827,189),(1118,342),(1135,172)]:
            glow(canvas,p,24,CYAN,70);diamond(canvas,*p,7)
        text('КАРТА МЕНЯЕТСЯ ПРИ КАЖДОМ ВХОДЕ',980,401,10,GOLD,True)
        for i,algo in enumerate(ALGORITHMS):
            x=40+i*303;active=i==self.selected
            box((x,446,288,243),(24,43,42) if active else PANEL,GOLD if active else LINE)
            text('0'+str(i+1),x+20,464,16,GOLD if active else MUTED)
            text(['DFS','PRIM','BSP','CELL'][i],x+220,466,12,MUTED)
            text(algo[1],x+20,500,21)
            text(algo[3],x+20,534,14,CYAN if active else MUTED)
            summaries=['Один путь вперёд. Возврат в тупике. Длинные извилистые коридоры.','Рост от границы в разные стороны. Частые развилки и короткие тупики.','Деление пространства на комнаты и соединение их коридорами.','Случайные стены сглаживаются по соседям и образуют пещеры.']
            thumbnail=pygame.transform.scale(self.preview[i],(135,92))
            canvas.blit(thumbnail,(x+20,559))
            wrap(summaries[i],x+166,562,105,12,MUTED,16)
            text('ВЫБРАНО' if active else 'ВЫБРАТЬ  →',x+20,659,12,GOLD if active else TEXT)
            self.buttons.append((pygame.Rect(x,446,288,243),'select:'+str(i)))
        text('W A S D  —  движение     /     Соберите 3 кристалла     /     Берегите три жизни',40,723,14,MUTED)
        self.button('Об игре и авторе',(1048,716,192,40),'credits',small=True)
        text('ПРОЦЕДУРНАЯ ГЕНЕРАЦИЯ / УЧЕБНАЯ ИГРА',40,773,10,(78,103,100))

    def draw_board(self):
        """Рисует либо снимок алгоритма, либо живой мир с динамическим светом."""
        box((32, 150, 824, 584), (8, 18, 20), LINE)
        if self.mode == "learn":
            frame = self.level.frames[self.frame]
            if self.lesson_board is None:
                self.lesson_board = terrain(frame.grid, self.level.seed, algorithm=self.level.algorithm)
            canvas.blit(self.lesson_board, (MAPX, MAPY))

            # Золотые рамки отмечают клетки, изменённые с предыдущего шага.
            if self.frame:
                previous = self.level.frames[self.frame - 1].grid
                for y in range(HEIGHT):
                    for x in range(WIDTH):
                        if previous[y][x] != frame.grid[y][x]:
                            pygame.draw.rect(canvas, GOLD, (MAPX + x * TILE + 3,
                                             MAPY + y * TILE + 3, TILE - 6, TILE - 6), 2)
            for x, y, width, height in frame.regions:
                pygame.draw.rect(canvas, GOLD, (MAPX + x * TILE, MAPY + y * TILE,
                                 width * TILE, height * TILE), 2)
            pulse = 10 + int((math.sin(self.t * 5) + 1) * 2)
            for position in frame.focus:
                x, y = self.position(position)
                glow(canvas, (x, y), 24, CYAN, 60)
                pygame.draw.rect(canvas, CYAN, (x - pulse, y - pulse, pulse * 2, pulse * 2), 2)
            return

        canvas.blit(self.board, (MAPX, MAPY))
        exit_x, exit_y = self.position(self.level.exit)
        opened = len(self.collected) == 3
        if opened:
            glow(canvas, (exit_x, exit_y), 58, CYAN, 115)
            # Концентрические дуги делают активный портал заметным издалека.
            for radius in (9, 15):
                pygame.draw.circle(canvas, CYAN, (int(exit_x), int(exit_y)), radius, 1)
        pygame.draw.rect(canvas, (7, 18, 21), (exit_x - 10, exit_y - 11, 20, 24), border_radius=5)
        pygame.draw.rect(canvas, CYAN if opened else GOLD,
                         (exit_x - 10, exit_y - 11, 20, 24), 2, border_radius=5)
        if not opened:
            for offset in (-4, 3):
                pygame.draw.line(canvas, (121, 112, 75), (exit_x + offset, exit_y - 8),
                                 (exit_x + offset, exit_y + 9), 2)
        else:
            pygame.draw.polygon(canvas, CYAN, [(exit_x, exit_y - 7),
                                (exit_x - 5, exit_y + 3), (exit_x + 5, exit_y + 3)])
        for i, position in enumerate(self.level.crystals):
            if i not in self.collected:
                x, y = self.position(position)
                y += math.sin(self.t * 2 + i) * 2
                glow(canvas, (x, y), 29, CYAN, 95)
                diamond(canvas, x, y, 11)
        for i, enemy in enumerate(self.enemies):
            x, y = self.position(enemy["p"])
            spider(canvas, x, y, self.t, i)

        # Затемнение вырезается градиентной маской: центр яркий, края в тумане.
        x, y = self.position(self.player)
        self.darkness.fill((3, 9, 11, 158))
        mask_x, mask_y = int(x - MAPX - 180), int(y - MAPY - 180)
        # Явное отсечение важно у краёв карты: отрицательный blit с вычитанием
        # альфа-канала в некоторых SDL-версиях иначе оставляет светлую полосу.
        map_bounds = self.darkness.get_rect()
        destination = pygame.Rect(mask_x, mask_y, 360, 360).clip(map_bounds)
        if destination.width and destination.height:
            source = pygame.Rect(destination.x - mask_x, destination.y - mask_y,
                                 destination.width, destination.height)
            self.darkness.blit(self.torch_cutout, destination, source,
                               special_flags=pygame.BLEND_RGBA_SUB)
        canvas.blit(self.darkness, (MAPX, MAPY))
        canvas.blit(self.light, (x - 170, y - 170))

        # Несколько математически движущихся искр оживляют даже неподвижную сцену.
        for i in range(7):
            angle = self.t * (.5 + i * .07) + i * 2.1
            spark_x = x - 17 + math.sin(angle) * (10 + i * 2)
            spark_y = y - 23 - ((self.t * 15 + i * 11) % 45)
            pygame.draw.circle(canvas, (239, 173 + i * 5, 77),
                               (int(spark_x), int(spark_y)), 1 if i % 2 else 2)
        if not self.invincible or int(self.t * 10) % 2 == 0:
            hero(canvas, x, y, self.t, 1.25)

    def hearts(self):
        for i in range(3):
            x=1082+i*49;y=116;c=(226,106,89) if i<self.health else (48,59,57)
            pygame.draw.circle(canvas,c,(x-5,y-3),7);pygame.draw.circle(canvas,c,(x+5,y-3),7)
            pygame.draw.polygon(canvas,c,[(x-12,y-1),(x+12,y-1),(x,y+13)])

    def gameplay(self):
        a=ALGORITHMS[self.selected]
        if self.mode=='learn':self.learning_tabs()
        else:text(a[2],40,110,26)
        self.draw_board()
        if self.mode=='learn':self.lesson_panel();return
        self.hearts()
        text('КАК РАБОТАЕТ АЛГОРИТМ',894,165,13,GOLD)
        heading_end=wrap(a[2],894,196,342,25,TEXT,29)
        description_end=wrap(a[4],894,heading_end+12,342,18,MUTED,24)
        genre_y=max(337,description_end+5)
        text('ДЛЯ КАКИХ ЖАНРОВ',894,genre_y,10,GOLD)
        wrap(a[6],894,genre_y+19,342,13,TEXT,17)
        for i in range(3):
            x=926+i*71
            box((x-30,474,60,59),(23,43,43),CYAN if i in self.collected else LINE,8)
            diamond(canvas,x,504,13,CYAN if i in self.collected else (68,93,89))
        text(f'{len(self.collected)} / 3',1178,494,25,CYAN)
        pygame.draw.line(canvas,LINE,(894,431),(1238,431))
        text('Выход открыт' if len(self.collected)==3 else 'Соберите 3 кристалла для выхода',894,445,17,GOLD)
        text('ДВИЖЕНИЕ · W A S D',1069,548,11,MUTED,True)
        symbols={'up':'↑','left':'←','down':'↓','right':'→'}
        for key,rect in self.dpad.items():
            pressed=any(rect.collidepoint(p) for p in self.fingers.values()) or (self.mouse_down and rect.collidepoint(self.mouse))
            box(rect,(40,65,61) if pressed else (21,37,39),GOLD if pressed else LINE,8)
            cx,cy=rect.center
            triangle=[(-9,5),(0,-6),(9,5)]
            turns={'up':0,'right':1,'down':2,'left':3}[key]
            for _ in range(turns):triangle=[(-y,x) for x,y in triangle]
            pygame.draw.polygon(canvas,TEXT,[(cx+x,cy+y) for x,y in triangle])
        self.button('Пауза',(1134,34,104,42),'pause',small=True)
        self.button('К алгоритмам',(894,739,158,40),'menu',small=True)
        self.button('Построение',(1066,739,172,40),'thislearn',small=True)
        text('Стражи следуют своим маршрутам. Пропустите их и двигайтесь дальше.',40,755,14,MUTED)
        if self.toast_time>0:
            box((215,680,454,38),(21,47,43),CYAN,8);text(self.toast,442,699,15,CYAN,True)
        if self.paused:self.overlay('Передышка','Лабиринт подождёт.',['Продолжить','К алгоритмам'],['pause','menu'])
        elif self.mode=='lost':self.overlay('Факел погас','Попробуйте снова — карта и маршруты останутся прежними.',['Повторить карту','К алгоритмам'],['retry','menu'])
        elif self.mode=='won':self.overlay('Путь найден','Три кристалла собраны. Какой мир исследуем теперь?',['Выбрать алгоритм'],['menu'],True)

    def learning_tabs(self):
        labels=['Введение','Поиск в глубину','Алгоритм Прима','BSP','Клеточный автомат']
        for i,label in enumerate(labels):
            self.button(label,(32+i*244,105,232,43),'intro' if i==0 else 'chapter:'+str(i-1),active=(self.mode=='intro' if i==0 else self.mode=='learn' and self.selected==i-1))

    def introduction(self):
        self.learning_tabs()
        text('Что такое процедурная генерация?',48,173,34)
        wrap('Это создание содержимого программой по набору правил. Разработчик задаёт алгоритм и параметры, а программа строит множество вариантов вместо ручного создания каждого из них.',48,228,1160,25,TEXT,34)
        steps=[('1. Правила и параметры','Задаём размеры, ограничения и допустимые элементы.'),('2. Алгоритм и seed','Seed — начальное число: с ним случайные решения можно повторить.'),('3. Результат и проверка','Получаем новый вариант и проверяем, соблюдены ли ограничения.')]
        for i,(title,body) in enumerate(steps):
            x=48+i*399
            box((x,352,382,156))
            text(title,x+18,371,23,GOLD)
            wrap(body,x+18,412,346,22,TEXT,29)
        text('Как это используют в играх',48,536,28)
        wrap('Так создают ландшафты, подземелья, растения, расположение предметов и задания. Случайность даёт разнообразие, а правила удерживают результат в рамках замысла разработчика.',48,580,1160,24,TEXT,32)
        text('Изучите все четыре подхода: вкладки сверху доступны в любом разделе.',48,678,23,CYAN)
        self.button('Начать с DFS',(48,725,260,48),'chapter:0',True)
        self.button('Вернуться к игре',(984,725,250,48),'menu')

    def lesson_panel(self):
        """Синхронно показывает объяснение, код, применение и органы управления."""
        frame = self.level.frames[self.frame]
        algorithm = ALGORITHMS[self.selected]
        wrap(algorithm[2], 894, 148, 342, 22, TEXT, 26)
        text(f"Шаг {self.frame + 1} из {len(self.level.frames)}", 894, 207, 17, GOLD)
        text(f"seed: {self.level.seed}", 1072, 209, 12, MUTED)
        text(algorithm[7], 894, 232, 12, CYAN)
        pygame.draw.rect(canvas, LINE, (894, 252, 342, 4), border_radius=2)
        pygame.draw.rect(canvas, CYAN, (894, 252,
                         int(342 * (self.frame + 1) / len(self.level.frames)), 4), border_radius=2)
        wrap(frame.message, 894, 268, 342, 17, TEXT, 23)
        code_block(frame.code, (894, 356, 342, 140))

        # Практический вывод закрепляет связь математического правила и жанра.
        box((894, 503, 342, 83), (20, 37, 35), (56, 79, 64), 8)
        text("ГДЕ ИСПОЛЬЗОВАТЬ", 906, 511, 12, GOLD)
        wrap(algorithm[6], 906, 532, 318, 14, TEXT, 18)

        self.button("Пауза" if self.auto else "Продолжить",
                    (894, 594, 164, 42), "auto", True)
        self.button("Следующий шаг", (1072, 594, 164, 42), "step", small=True)
        self.button(f"Скорость ×{self.lesson_speed:g}", (894, 644, 164, 42), "speed", small=True)
        self.button("Сгенерировать заново", (1072, 644, 164, 42), "regenerate", small=True)
        self.button("Играть на этой карте", (894, 700, 342, 42), "lessonplay")
        self.button("К игре", (1134, 34, 104, 42), "menu", small=True)
        text("Золотой — изменённые клетки и области · бирюзовый — активные узлы",
             40, 754, 16, TEXT)

    def overlay(self,title,subtitle,labels,actions,success=False):
        shade=pygame.Surface((W,H),pygame.SRCALPHA);shade.fill((3,10,13,210));canvas.blit(shade,(0,0))
        self.buttons=[]
        box((330,238,620,315),(18,34,35),GOLD if success else LINE,16)
        diamond(canvas,640,284,16,GOLD if success else CYAN)
        text(title,640,335,36,TEXT,True)
        wrap(subtitle,380,376,520,18,MUTED,26)
        for i,label in enumerate(labels):
            width=240 if len(labels)>1 else 400;x=385+i*270 if len(labels)>1 else 440
            self.button(label,(x,463,width,54),actions[i],i==0)

    def credits(self):
        text('ОБ ИГРЕ',640,163,13,GOLD,True)
        text('Живой лабиринт',640,213,47,TEXT,True)
        wrap('Учебная игра о процедурной генерации. Один набор правил создаёт тысячи миров: исследуйте их, а затем посмотрите, как они строятся.',346,285,588,21,MUTED,32)
        pygame.draw.line(canvas,LINE,(346,411),(934,411))
        text('АВТОР',640,452,13,GOLD,True)
        text('Аслалиев Аслали Шумалович',640,497,29,TEXT,True)
        text('Python · Pygame · Pygbag',640,553,17,MUTED,True)
        text('Графика создана программно специально для игры.',640,588,15,MUTED,True)
        self.button('Вернуться к алгоритмам',(450,659,380,54),'menu',True)

    def draw(self):
        canvas.fill(BG);self.buttons=[];self.header()
        if self.mode=='menu':self.menu()
        elif self.mode=='credits':self.credits()
        elif self.mode=='intro':self.introduction()
        else:self.gameplay()

def viewport():
    sw,sh=screen.get_size();scale=min(sw/W,sh/H)
    return scale,(sw-W*scale)/2,(sh-H*scale)/2

def translated(pos):
    scale,ox,oy=viewport();return ((pos[0]-ox)/scale,(pos[1]-oy)/scale)

async def main():
    game=Game();clock=pygame.time.Clock();running=True
    if sys.platform=='emscripten':
        import platform
        platform.window.mazeReady=True
    while running:
        dt=min(clock.tick(60)/1000,.045)
        for event in pygame.event.get():
            if event.type==pygame.QUIT:running=False
            elif event.type==pygame.WINDOWFOCUSLOST:
                game.fingers.clear();game.mouse_down=False
                # Parent-page touch controls must not pause the embedded canvas.
                hidden=True
                if sys.platform=='emscripten':
                    import platform
                    hidden=bool(platform.document.hidden)
                if game.mode=='play' and hidden:game.paused=True
            elif event.type==pygame.KEYDOWN:
                if event.key==pygame.K_ESCAPE:
                    if game.mode=='play':game.action('pause')
                    elif game.mode!='menu':game.action('menu')
                elif event.key==pygame.K_m:
                    game.action('mute')
                elif event.key==pygame.K_SPACE:
                    if game.mode=='learn':game.action('step')
                    elif game.mode=='menu':game.action('play')
                elif event.key==pygame.K_RIGHT and game.mode=='learn':game.action('step')
                elif event.key==pygame.K_LEFT and game.mode=='learn':game.action('back')
            elif event.type==pygame.MOUSEMOTION:game.mouse=translated(event.pos)
            elif event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
                if getattr(event,'touch',False):continue
                game.mouse=translated(event.pos);game.mouse_down=True
                for rect,action in reversed(game.buttons):
                    if rect.collidepoint(game.mouse):game.action(action);break
            elif event.type==pygame.MOUSEBUTTONUP and event.button==1:game.mouse_down=False
            elif event.type in (pygame.FINGERDOWN,pygame.FINGERMOTION):
                sw,sh=screen.get_size();pos=translated((event.x*sw,event.y*sh));game.fingers[event.finger_id]=pos;game.touch=True
                if event.type==pygame.FINGERDOWN:
                    for rect,action in reversed(game.buttons):
                        if rect.collidepoint(pos):game.action(action);break
            elif event.type==pygame.FINGERUP:game.fingers.pop(event.finger_id,None)
        game.update(dt);game.draw()
        scale,ox,oy=viewport();screen.fill(BG)
        if abs(scale-1)<.001:
            screen.blit(canvas,(0,0))  # Не копируем полный кадр при родном размере.
        else:
            scaled=pygame.transform.smoothscale(canvas,(max(1,round(W*scale)),max(1,round(H*scale))))
            screen.blit(scaled,(round(ox),round(oy)))
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()

if __name__=='__main__':asyncio.run(main())
