"""Четыре генератора карт и запись их работы для учебного режима.

Модуль намеренно не зависит от Pygame: алгоритмы можно проверять отдельно,
а один и тот же seed всегда создаёт одинаковую карту.
"""
import random
from collections import deque
from dataclasses import dataclass

# Нечётные размеры удобны DFS и Прима: узлы лабиринта стоят через клетку.
WIDTH, HEIGHT = 25, 17
DIRECTIONS = ((1, 0), (-1, 0), (0, 1), (0, -1))

# Последние два поля — практическая рекомендация и оценка для учебной панели.
ALGORITHMS = [
    ("dfs", "Нить исследователя", "Поиск в глубину (DFS)", "Длинные коридоры",
     "Идёт к непосещённому соседу, а из тупика возвращается по стеку к последней развилке.",
     "Обход графов и построение лабиринтов.",
     "Лучше: головоломки и roguelike-лабиринты, где важны длинные запутанные маршруты.",
     "O(W×H) по времени и памяти"),
    ("prim", "Переплетение", "Алгоритм Прима", "Случайный вариант",
     "Наращивает дерево, случайно присоединяя клетки с границы уже готовой области.",
     "Остовные деревья и лабиринты с частыми развилками.",
     "Лучше: приключения и игры с исследованием, где нужны короткие ответвления и тупики.",
     "O(W×H) при случайном списке границы"),
    ("bsp", "Забытые чертоги", "Двоичное разбиение (BSP)", "Разделение пространства",
     "Рекурсивно делит пространство, размещает комнаты в листьях и соединяет части коридорами.",
     "Генерация помещений и организация пространства.",
     "Лучше: roguelike, тактические игры и шутеры с комнатами, зданиями и аренами.",
     "O(W×H) на карту; дерево областей дополнительно"),
    ("cave", "Дыхание пещеры", "Клеточный автомат", "Локальные правила",
     "Синхронно меняет клетки по числу соседей: простой локальный закон создаёт природные формы.",
     "Моделирование процессов и генерация природных форм.",
     "Лучше: выживание, платформеры и исследования с пещерами, островами и органическим рельефом.",
     "O(W×H×N), где N — число сглаживаний"),
]


def neighbours(p, grid):
    """Возвращает доступные клетки в четырёх ортогональных направлениях."""
    x, y = p
    for dx, dy in DIRECTIONS:
        q = x + dx, y + dy
        if 0 <= q[0] < WIDTH and 0 <= q[1] < HEIGHT and grid[q[1]][q[0]] == 0:
            yield q


def distances(grid, start):
    """Обход в ширину: расстояния от start до всех достижимых проходов."""
    result = {start: 0}
    queue = deque([start])
    while queue:
        p = queue.popleft()
        for q in neighbours(p, grid):
            if q not in result:
                result[q] = result[p] + 1
                queue.append(q)
    return result


def path_between(grid, start, end, allowed=None):
    """Находит короткий маршрут и восстанавливает его по словарю родителей."""
    queue, parents = deque([start]), {start: None}
    while queue:
        p = queue.popleft()
        if p == end:
            route = []
            while p is not None:
                route.append(p)
                p = parents[p]
            return route[::-1]
        for q in neighbours(p, grid):
            if q not in parents and (allowed is None or q in allowed):
                parents[q] = p
                queue.append(q)
    return []

@dataclass
class Frame:
    """Снимок сетки и пояснение одного учебного шага."""
    grid: tuple
    focus: tuple
    message: str
    regions: tuple = ()
    code: tuple = ()  # Строки упрощённого фрагмента соответствующего алгоритма.

@dataclass
class Level:
    algorithm: str
    seed: int
    grid: list
    frames: list
    start: tuple
    exit: tuple
    crystals: list
    patrols: list

def generate(algorithm, seed):
    """Строит связный уровень и возвращает Level с учебными снимками.

    Локальный Random не зависит от глобального состояния random, поэтому тесты,
    миниатюры и повторная генерация одного seed дают одинаковый результат.
    """
    rng = random.Random(seed)
    grid = [[1] * WIDTH for _ in range(HEIGHT)]
    frames = []

    def record(message, focus=(), regions=()):
        """Копирует сетку: последующие операции не меняют старые снимки."""
        frames.append(Frame(tuple(tuple(row) for row in grid), tuple(focus), message, tuple(regions)))

    def carve(p):
        grid[p[1]][p[0]] = 0

    def tunnel(a, b):
        """Прорезает Г-образный проход между центрами областей."""
        x, y = a
        while x != b[0]:
            carve((x, y)); x += 1 if b[0] > x else -1
        while y != b[1]:
            carve((x, y)); y += 1 if b[1] > y else -1
        carve(b)

    record("Начинаем с пустого пространства для будущей карты.")
    if algorithm == "dfs":
        # Стек хранит путь; ходим через две клетки, оставляя стены между узлами.
        stack = [(1, 1)]
        carve(stack[0])
        while stack:
            x, y = stack[-1]
            choices = [(x+dx*2,y+dy*2) for dx,dy in DIRECTIONS if 0<x+dx*2<WIDTH-1 and 0<y+dy*2<HEIGHT-1 and grid[y+dy*2][x+dx*2]]
            if choices:
                q = rng.choice(choices)
                carve(((x+q[0])//2,(y+q[1])//2)); carve(q); stack.append(q)
                record("Идём в непосещённую клетку и добавляем её в стек.", [q])
            else:
                stack.pop()
                record("Тупик: возвращаемся по стеку к последней развилке.", stack[-1:])
    elif algorithm == "prim":
        origin = (WIDTH//2 | 1, HEIGHT//2 | 1)
        carve(origin); frontier = [(origin[0]+dx*2,origin[1]+dy*2) for dx,dy in DIRECTIONS]
        while frontier:
            p = frontier.pop(rng.randrange(len(frontier)))
            x,y=p
            if not grid[y][x]: continue
            opened=[(x+dx*2,y+dy*2) for dx,dy in DIRECTIONS if 0<x+dx*2<WIDTH-1 and 0<y+dy*2<HEIGHT-1 and not grid[y+dy*2][x+dx*2]]
            q=rng.choice(opened)
            carve(p);carve(((x+q[0])//2,(y+q[1])//2))
            for dx,dy in DIRECTIONS:
                nx,ny=x+dx*2,y+dy*2
                if 0<nx<WIDTH-1 and 0<ny<HEIGHT-1 and grid[ny][nx] and (nx,ny) not in frontier: frontier.append((nx,ny))
            record("Присоединяем случайную клетку границы одним проходом.", [p]+frontier)
    elif algorithm == "bsp":
        leaves=[]
        def divide(x,y,w,h):
            vertical = w > h if w != h else rng.choice([True,False])
            if w>=14 and h>=14: vertical=rng.choice([True,False])
            if (vertical and w>=14) or (not vertical and h>=14):
                cut=rng.randint(7,(w if vertical else h)-7)
                rects = [(x,y,cut,h),(x+cut,y,w-cut,h)] if vertical else [(x,y,w,cut),(x,y+cut,w,h-cut)]
                record("Делим область на две части; каждая получит свою комнату.",regions=rects)
                a=divide(*rects[0]);b=divide(*rects[1]);tunnel(a,b)
                record("Соединяем две уже связанные части коридором.",[a,b])
                return a
            rw,rh=rng.randint(3,w-2),rng.randint(3,h-2)
            rx,ry=rng.randint(x+1,x+w-rw-1),rng.randint(y+1,y+h-rh-1)
            for yy in range(ry,ry+rh):
                for xx in range(rx,rx+rw):carve((xx,yy))
            center=(rx+rw//2,ry+rh//2);leaves.append(center)
            record("Внутри конечной области создаём комнату.",[center],[(x,y,w,h)])
            return center
        divide(1,1,WIDTH-2,HEIGHT-2)
    elif algorithm == "cave":
        for y in range(1,HEIGHT-1):
            for x in range(1,WIDTH-1):grid[y][x]=int(rng.random()<0.44)
        record("Случайное заполнение: примерно 44% внутренних клеток — стены.")
        for step in range(5):
            new=[[1]*WIDTH for _ in range(HEIGHT)]
            for y in range(1,HEIGHT-1):
                for x in range(1,WIDTH-1):
                    walls=sum(grid[y+dy][x+dx] for dx in (-1,0,1) for dy in (-1,0,1) if dx or dy)
                    new[y][x]=int(walls>=5 or (grid[y][x] and walls>=4))
            grid=new
            record(f"Сглаживание {step+1}/5: стена сохраняется при 4 соседях, рождается при 5.")
    else: raise ValueError(algorithm)
    floors=[(x,y) for y in range(1,HEIGHT-1) for x in range(1,WIDTH-1) if not grid[y][x]]
    if len(floors)<12:
        for y in range(HEIGHT//2-2,HEIGHT//2+3):
            for x in range(WIDTH//2-3,WIDTH//2+4):carve((x,y))
        record("Резервная камера: добавляем пространство для безопасного старта.")
        floors=[(x,y) for y in range(1,HEIGHT-1) for x in range(1,WIDTH-1) if not grid[y][x]]
    # Connect every component; the same correction is visible in the lesson.
    start=min(floors,key=lambda p:p[0]+p[1])
    connected=distances(grid,start)
    while len(connected)<len(floors):
        outside=[p for p in floors if p not in connected]
        a,b=min(((a,b) for a in connected for b in outside),key=lambda pair:abs(pair[0][0]-pair[1][0])+abs(pair[0][1]-pair[1][1]))
        tunnel(a,b);record("Найдена отдельная область: соединяем её с основной пещерой.",[a,b])
        floors=[(x,y) for y in range(1,HEIGHT-1) for x in range(1,WIDTH-1) if not grid[y][x]]
        connected=distances(grid,start)
    exit_cell=max(connected,key=connected.get)
    # Spread objectives by graph distance, not by visual distance through walls.
    selected=[start,exit_cell]; crystals=[]
    distmaps=[distances(grid,p) for p in selected]
    for _ in range(3):
        candidates=[p for p in floors if p not in selected and connected[p]>=4]
        p=max(candidates,key=lambda p:min(d[p] for d in distmaps))
        crystals.append(p);selected.append(p);distmaps.append(distances(grid,p))
    patrols=[]
    allowed={p for p in floors if connected[p]>5 and p!=exit_cell}
    candidates=sorted(allowed)
    rng.shuffle(candidates)
    for origin in candidates:
        if origin in crystals or any(origin in route for route in patrols):continue
        local={origin:None};queue=deque([origin]);ends=[]
        while queue:
            p=queue.popleft()
            route=path_between(grid,origin,p,allowed)
            if 4<=len(route)<=9:ends.append(route)
            if len(route)>=9:continue
            for q in neighbours(p,grid):
                if q in allowed and q not in local:local[q]=p;queue.append(q)
        if ends:patrols.append(rng.choice(ends))
        if len(patrols)==5:break
    record("Карта связна. Все кристаллы и выход достижимы. Можно играть.",[start,exit_cell]+crystals)
    return Level(algorithm,seed,grid,lesson_frames(algorithm, frames),start,exit_cell,crystals,patrols)


def lesson_frames(algorithm, raw):
    """Выбирает семь показательных снимков из сотен внутренних операций.

    Снапшоты показывают именно текущий алгоритм, а не заранее нарисованную
    анимацию. Текст и код упрощены для объяснения, но сохраняют его логику.
    """
    def first(fragment, fallback=None):
        return next((f for f in raw if fragment in f.message), fallback or raw[-1])

    common_start = (
        "Сетка хранит мир: 1 — стена, 0 — проход. Генератор будет менять эти числа, а игра превратит их в подземелье.",
        "Seed запускает генератор случайных чисел. Одинаковый seed повторяет карту, новый seed меняет решения, но не правила.")
    common_code = (
        ("grid = [[1] * WIDTH", "         for _ in range(HEIGHT)]", "# 1 = стена, 0 = проход"),
        ("rng = random.Random(seed)", "q = rng.choice(choices)", "# seed делает выбор повторяемым"))
    if algorithm == "dfs":
        forward = [f for f in raw if "непосещённую" in f.message]
        chosen = [raw[0], raw[0], forward[0], forward[5], first("Тупик:"),
                  forward[len(forward) * 3 // 4], raw[-1]]
        messages = [common_start[0], common_start[1],
            "Начинаем с угловой клетки. Стек запоминает путь: верхний элемент — текущая позиция исследователя.",
            "Смотрим на узлы через две клетки, выбираем непосещённый и удаляем стену между ним и текущей позицией.",
            "Если соседей нет, стек выполняет возврат. Благодаря ему алгоритм находит ранее пропущенную развилку.",
            "Движение вглубь и возвраты продолжаются, пока стек не опустеет. Получаются длинные извилистые коридоры.",
            "Готово: это остовное дерево, поэтому между узлами один путь. DFS хорош для запутанных головоломок и roguelike."]
        snippets = [common_code[0], common_code[1],
            ("stack = [(1, 1)]", "carve(stack[0])", "while stack:", "    x, y = stack[-1]"),
            ("choices = neighbours_2(current)", "q = rng.choice(choices)", "carve(between(current, q))", "stack.append(q)"),
            ("if not choices:", "    stack.pop()", "    current = stack[-1]", "# возврат к развилке"),
            ("while stack:", "    visit(current)", "    # вперёд или назад", "# пока стек не пуст"),
            ("connected = distances(grid, start)", "assert exit_cell in connected", "# проверка достижимости")]
    elif algorithm == "prim":
        growth = raw[1:-1]
        chosen = [raw[0], raw[0], growth[0], growth[len(growth) // 3],
                  growth[len(growth) * 2 // 3], growth[-2], raw[-1]]
        messages = [common_start[0], common_start[1],
            "Начинаем в центре. Непосещённые соседи попадают в список границы — кандидатов на присоединение.",
            "Выбираем случайного кандидата и проводим один проход к уже построенной области.",
            "Новые соседи пополняют границу. Поэтому рост идёт сразу в нескольких местах, а не одной цепью, как в DFS.",
            "Каждая клетка присоединяется одним ребром. Циклы не возникают, зато появляется много коротких тупиков.",
            "Готово: ветвистая сеть удобна для приключений и исследований с необязательными закоулками и наградами."]
        snippets = [common_code[0], common_code[1],
            ("origin = (WIDTH//2 | 1, HEIGHT//2 | 1)", "carve(origin)", "frontier = neighbours_2(origin)"),
            ("p = frontier.pop(random_index)", "q = opened_neighbor(p)", "carve(p)", "carve(between(p, q))"),
            ("for q in neighbours_2(p):", "    if is_wall(q):", "        frontier.append(q)"),
            ("while frontier:", "    join_random_candidate()", "    update_frontier()", "# по одному ребру на узел"),
            ("connected = distances(grid, start)", "assert exit_cell in connected", "# проверка достижимости")]
    elif algorithm == "bsp":
        chosen = [raw[0], raw[0], first("Делим"), first("Внутри"),
                  first("Соединяем"), raw[-2], raw[-1]]
        messages = [common_start[0], common_start[1],
            "Берём всю доступную область. Дерево BSP будет хранить не клетки, а прямоугольные части пространства.",
            "Делим большую область по вертикали или горизонтали. Золотые рамки показывают две новые части.",
            "В маленькой конечной области размещаем комнату со случайными размерами и обязательными отступами.",
            "После обработки двух ветвей соединяем их комнаты коридором. Так связность строится вместе с деревом.",
            "Повторяем деление и соединение на каждом уровне. Минимальный размер области управляет масштабом комнат.",
            "Готово: чёткие комнаты и переходы подходят для тактик, шутеров и roguelike в зданиях или на станциях."]
        snippets = [common_code[0], common_code[1],
            ("divide(1, 1, WIDTH-2, HEIGHT-2)", "# рекурсивное деление", "# области хранит дерево BSP"),
            ("vertical = choose_direction(w, h)", "cut = rng.randint(7, size-7)", "left, right = split(area, cut)"),
            ("rw = rng.randint(3, w-2)", "rh = rng.randint(3, h-2)", "carve_room(rx, ry, rw, rh)"),
            ("a = divide(left)", "b = divide(right)", "tunnel(a, b)", "# соединяем две ветви"),
            ("if area_is_large:", "    divide(area)", "else:", "    create_room(area)"),
            ("connected = distances(grid, start)", "assert exit_cell in connected", "# проверка достижимости")]
    else:
        chosen = [raw[0], raw[0], first("Случайное заполнение"),
                  first("Сглаживание 1/"), first("Сглаживание 3/"),
                  first("Сглаживание 5/"), raw[-1]]
        messages = [common_start[0], common_start[1],
            "Сначала независимо заполняем клетки шумом: примерно 44% внутренней области станут стенами.",
            "Для каждой клетки считаем восемь соседей. Пять стен создают стену; существующей достаточно четырёх.",
            "Все клетки читают старую сетку и пишут в новую. Так обновление действительно происходит одновременно.",
            "Повторяем правило пять раз. Мелкий шум исчезает, а формы становятся плавными и похожими на пещеры.",
            "Сглаживание не гарантирует связность, поэтому обход в ширину находит отдельные области, а туннели соединяют их.",
            "Готово: органические полости подходят для выживания, платформеров и исследования природных пещер."]
        snippets = [common_code[0], common_code[1],
            ("for cell in inner_cells:", "    grid[cell] = int(", "        rng.random() < 0.44", "    )"),
            ("walls = count_walls_8(cell)", "new[cell] = int(", "    walls >= 5 or", "    (grid[cell] and walls >= 4)", ")"),
            ("new = empty_grid()", "for cell in inner_cells:", "    update(new, cell, grid)", "grid = new"),
            ("for step in range(5):", "    grid = smooth(grid)", "# одно правило, пять тактов"),
            ("connected = distances(grid, start)", "for region in separate_regions:", "    tunnel(region, connected)")]
    return [Frame(frame.grid, frame.focus if i < 6 else (), message,
                  frame.regions, snippets[i])
            for i, (frame, message) in enumerate(zip(chosen, messages))]
