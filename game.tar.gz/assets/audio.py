"""Синтез звука без внешних аудиофайлов.

Все эффекты создаются из синусоид и шума через стандартный модуль ``array``.
Это одинаково работает в настольном Pygame и в браузерной сборке Pygbag.
"""
from array import array
import math
import random
import sys

import pygame


class AudioSystem:
    """Небольшой звуковой движок: эффекты и постоянное отключение звука."""

    SAMPLE_RATE = 22050

    def __init__(self):
        self.ready = False
        self.failed = False
        self.sounds = {}
        self.muted = self._load_mute_preference()

    def _load_mute_preference(self):
        """Восстанавливает настройку; в обычном Python просто включает звук."""
        if sys.platform != "emscripten":
            return False
        try:
            import platform
            return platform.window.localStorage.getItem("living-maze-muted") == "1"
        except (AttributeError, TypeError):
            return False

    def _save_mute_preference(self):
        """Сохраняет настройку только локально в браузере игрока."""
        if sys.platform != "emscripten":
            return
        try:
            import platform
            platform.window.localStorage.setItem("living-maze-muted", "1" if self.muted else "0")
        except (AttributeError, TypeError):
            pass

    @classmethod
    def _pcm16(cls, samples):
        """Преобразует значения [-1; 1] в формат, который понимает Pygame."""
        data = array("h", (int(max(-1.0, min(1.0, value)) * 32767) for value in samples))
        return data.tobytes()

    def _effect(self, kind):
        """Создаёт короткий сигнал с огибающей, чтобы не было щелчков."""
        durations = {"click": .07, "step": .09, "crystal": .55, "hit": .28,
                     "portal": .8, "win": 1.1, "lose": .75, "tick": .12}
        duration = durations[kind]
        rng = random.Random(710 + len(self.sounds))
        samples = []
        for i in range(int(self.SAMPLE_RATE * duration)):
            t = i / self.SAMPLE_RATE
            p = t / duration
            envelope = min(1.0, t / .012) * (1.0 - p) ** 1.7
            noise = rng.uniform(-1, 1)
            if kind == "click":
                value = math.sin(2 * math.pi * (520 - 180 * p) * t) * .24
            elif kind == "step":
                value = (noise * .28 + math.sin(2 * math.pi * 95 * t) * .25) * .45
            elif kind == "crystal":
                frequency = 660 if p < .32 else (880 if p < .64 else 1320)
                value = (math.sin(2 * math.pi * frequency * t) +
                         .3 * math.sin(2 * math.pi * frequency * 2 * t)) * .36
            elif kind == "hit":
                value = (noise * .55 + math.sin(2 * math.pi * (120 - 55 * p) * t) * .5) * .65
            elif kind == "portal":
                value = (math.sin(2 * math.pi * (220 + 500 * p) * t) * .35 +
                         math.sin(2 * math.pi * 330 * t) * .15)
            elif kind == "win":
                notes = (523.25, 659.25, 783.99, 1046.5)
                frequency = notes[min(3, int(p * 4))]
                value = math.sin(2 * math.pi * frequency * t) * .32
            elif kind == "lose":
                value = (math.sin(2 * math.pi * (190 - 105 * p) * t) * .4 + noise * .08)
            else:  # Короткий звук смены учебного шага.
                value = math.sin(2 * math.pi * (420 + 120 * p) * t) * .2
            samples.append(value * envelope)
        return pygame.mixer.Sound(buffer=self._pcm16(samples))

    def unlock(self):
        """Вызывается после нажатия: браузеры разрешают звук только из жеста."""
        if self.failed or self.ready:
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=self.SAMPLE_RATE, size=-16, channels=1, buffer=512)
            for name in ("click", "step", "crystal", "hit", "portal", "win", "lose", "tick"):
                self.sounds[name] = self._effect(name)
            self.ready = True
        except (pygame.error, AttributeError, NotImplementedError):
            # Игра остаётся полностью работоспособной даже без аудиоустройства.
            self.failed = True

    def play(self, name, volume=1.0):
        """Проигрывает эффект, если звук уже разблокирован пользовательским жестом."""
        if not self.ready or self.muted or name not in self.sounds:
            return
        channel = self.sounds[name].play()
        if channel:
            channel.set_volume(volume)

    def toggle(self):
        self.muted = not self.muted
        self._save_mute_preference()
        if not self.muted:
            self.unlock()
            self.play("click", .7)
